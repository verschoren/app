# VIP Notifier

![assets/logo.png](assets/logo.png)


This app notifies agents that the current ticket requester is a VIP user, based on a tag set on the user.

![assets/screenshot-0.png](assets/screenshot-0.png)